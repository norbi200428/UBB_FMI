public interface MainDish {
    @Override
    String toString();
}
