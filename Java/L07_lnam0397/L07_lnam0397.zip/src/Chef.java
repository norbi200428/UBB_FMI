public interface Chef {
    Soup prepareSoup();
    MainDish prepareMainDish();
}
