public interface Soup {
    void associateMainDish(MainDish mainDish);
    String toString();
}
