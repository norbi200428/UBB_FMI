public class ChickpeaCurry implements MainDish {
    public String toString() {
        return this.getClass().getSimpleName();
    }
}
