import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.Buffer;

public class Pipe {
    private int x = 500, y = 0;
    private int WIDTH = 32, HEIGHT = 400, GAP = 90;
    private final BufferedImage topPipeImage;
    private final BufferedImage bottomPipeImage;
    private int velocity = -5;
    private boolean passed = false;

    public Pipe() {
        try {
            topPipeImage = ImageIO.read(new File("img/toppipe.png"));
            bottomPipeImage = ImageIO.read(new File("img/bottompipe.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void move() {
        x += velocity;
    }

    public void render(Graphics g) {
        g.drawImage(topPipeImage, x, y, WIDTH, HEIGHT, null);
        g.drawImage(bottomPipeImage, x, y + HEIGHT + GAP, WIDTH, 575 - HEIGHT - GAP, null);
    }

    public boolean isColliding(Bird bird){
        Rectangle birdBounds = new Rectangle(bird.getBirdX(),bird.getBirdY(),bird.getBirdWidth(),bird.getBirdHeight());
        Rectangle topPipeBounds = new Rectangle(x,y,WIDTH,HEIGHT);
        Rectangle bottomPipeBounds = new Rectangle(x,y+HEIGHT+GAP, WIDTH, 575 - HEIGHT - GAP);
        return birdBounds.intersects(topPipeBounds) || birdBounds.intersects(bottomPipeBounds);
    }

    public void setPipeY(int value) {
        y = value;
    }

    public int getPipeY() {
        return y;
    }

    public int getPipeX(){
        return x;
    }

    public int getPipeHeight() {
        return HEIGHT;
    }

    public void setPipeHeight(int value) {
        HEIGHT = value;
    }

    public int getPipeWidth(){
        return WIDTH;
    }

    public boolean isPassed(){
        return passed;
    }

    public void setPassed(){
        passed = true;
    }
}
