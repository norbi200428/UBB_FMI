import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Bird {
    private final int WIDTH = 36;
    private final int HEIGHT = 24;
    private final int GRAVITY = 1;
    private final int JUMP_STRENGTH = -10;

    private final BufferedImage birdImage;
    private int x;
    private int y;
    private int velocity = 0;

    public Bird(int x, int y) {
        this.x = x;
        this.y = y;

        try {
            birdImage = ImageIO.read(new File("img/flappybird.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public void updatePos() {
        velocity += GRAVITY;
        setY(y + velocity);
    }

    public int getBirdX() {
        return x;
    }

    public int getBirdY() {
        return y;
    }

    public int getBirdWidth() {
        return WIDTH;
    }

    public int getBirdHeight() {
        return HEIGHT;
    }

    public void setY(int value) {
        if (value > 0) {
            y = Math.min(550, value);
        } else {
            y = 0;
        }
    }

    public void setVelocity(int value) {
        this.velocity = value;
    }

    public void jump() {
        velocity = JUMP_STRENGTH;
    }

    public void renderBird(Graphics g) {
        g.drawImage(birdImage, x, y, WIDTH, HEIGHT, null);
    }
}
