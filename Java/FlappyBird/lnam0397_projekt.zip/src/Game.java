import javax.swing.*;
import java.awt.*;

public class Game extends JFrame {
    private final CardLayout cardLayout;
    private final JPanel mainPanel;
    public int maxScore = 0;
    public GamePanel gamePanel;

    public Game() {
        setTitle("Flappy Bird Game");
        setSize(500, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);


        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        gamePanel = new GamePanel(this);
        mainPanel.add(new StartMenu(this), "Menu");
        mainPanel.add(gamePanel, "Game");

        mainPanel.requestFocus();
        add(mainPanel);

        showPanel("Menu");
        setVisible(true);
    }

    public void showPanel(String name) {
        cardLayout.show(mainPanel, name);
    }

    public static void main(String[] args) {
        new Game();
    }
}