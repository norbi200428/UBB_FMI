import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener, KeyListener {
    private final Game game;
    private final Bird bird;
    public Timer gameTimer;
    public Timer placePipesTimer;
    private final int WIDTH;
    private final int HEIGHT;
    private final BufferedImage backgroundImage;
    private ArrayList<Pipe> pipes;
    private boolean gameOver = false;
    private int score = 0;


    public GamePanel(Game game) {
        setFocusable(true);
        this.game = game;
        WIDTH = game.getWidth();
        HEIGHT = game.getHeight();
        Random random = new Random();

        try {
            backgroundImage = ImageIO.read(new File("img/background.jpg"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        this.bird = new Bird(WIDTH / 5, HEIGHT / 2);
        this.pipes = new ArrayList<>();

        gameTimer = new Timer(1000 / 60, this);
        placePipesTimer = new Timer(1500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                placePipes();
            }
        });

        addKeyListener(this);

    }

    public void placePipes() {
        Pipe pipe = new Pipe();
        pipe.setPipeHeight((int) (pipe.getPipeHeight() - Math.random() * ((double) (pipe.getPipeHeight() * 3) / 4)));
        pipes.add(pipe);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.drawImage(backgroundImage, 0, 0, WIDTH, HEIGHT, null);

        bird.renderBird(g);

        pipes.stream().forEach(pipe -> pipe.render(g));

        g.setColor(Color.white);
        g.setFont(new Font("Arial", Font.BOLD, 28));

        if (gameOver) {
            g.drawString("Game Over! You scored: " + String.valueOf((int) score) + "points.", 10, 35);
        } else {
            g.drawString("Your current score is: " + String.valueOf((int) score), 10, 35);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (gameOver || bird.getBirdY() + 24 >= 574) {
            AudioPlayer audioPlayer = new AudioPlayer("sound/dead.wav");
            audioPlayer.startMusic();
            bird.setY(HEIGHT / 2);
            bird.setVelocity(0);
            pipes.clear();
            gameOver = false;
            if(score > game.maxScore) game.maxScore = score;
            score = 0;
            gameTimer.stop();
            placePipesTimer.stop();
        } else {
            bird.updatePos();

            pipes.stream().forEach(Pipe::move);

            if (pipes.stream().anyMatch(pipe -> pipe.isColliding(bird))) {
                gameOver = true;
            }

            pipes.stream().filter(pipe -> !pipe.isPassed() && bird.getBirdX() > pipe.getPipeX() + pipe.getPipeWidth())
                            .forEach(pipe -> {pipe.setPassed();
                                                    score++;});
            repaint();
        }

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            bird.jump();
        } else if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
            game.showPanel("Menu");
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
