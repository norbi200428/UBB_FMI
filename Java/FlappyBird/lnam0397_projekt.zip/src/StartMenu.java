import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class StartMenu extends JPanel {
    private final AudioPlayer audioPlayer;

    public StartMenu(Game game) {
        audioPlayer = new AudioPlayer("sound/music.wav");

        setBackground(Color.CYAN);

        JPanel buttons = new JPanel();
        buttons.setLayout(new GridLayout(4, 1));

        JButton startButton = new JButton("Start");
        JButton helpButton = new JButton("Help");
        JButton musicButton = new JButton("Music On");
        JButton saveButton = new JButton("Save your max score");
        buttons.add(startButton);
        buttons.add(helpButton);
        buttons.add(musicButton);
        buttons.add(saveButton);

        add(buttons);

        startButton.addActionListener(_ -> {
            game.showPanel("Game");
            game.gamePanel.requestFocus();
            game.gamePanel.addKeyListener(new KeyListener() {
                @Override
                public void keyTyped(KeyEvent e) {

                }

                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                        game.gamePanel.placePipesTimer.start();
                        game.gamePanel.gameTimer.start();
                    }
                }

                @Override
                public void keyReleased(KeyEvent e) {

                }
            });
        });
        saveButton.addActionListener(_ -> saveHighScore(game.maxScore));
        helpButton.addActionListener(_ -> showHelp());
        musicButton.addActionListener(_ -> {
            if (audioPlayer.hasMusic()) {
                audioPlayer.stopMusic();
                musicButton.setText("Music On");
            } else {
                audioPlayer.startMusic();
                musicButton.setText("Music Off");
            }
        });

    }

    private void showHelp() {
        JOptionPane.showMessageDialog(this, "Instructions:\n Press SPACE to make the bird jump and avoid collision with the pipes.", "Help", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void saveHighScore(int highScore) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save High Score");

        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                writer.write("High Score: " + highScore);
                JOptionPane.showMessageDialog(null, "High score saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error saving high score: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}
