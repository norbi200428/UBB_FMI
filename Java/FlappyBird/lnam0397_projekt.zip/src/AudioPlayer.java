import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

public class AudioPlayer {
    private final Clip clip;
    private boolean isPlaying = false;

    public AudioPlayer(String name) {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(name));
            clip = AudioSystem.getClip();
            clip.open(audioInputStream);

        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            throw new RuntimeException(e);
        }
    }

    public void stopMusic(){
        clip.stop();
        isPlaying = false;
    }

    public void startMusic(){
        clip.start();
        isPlaying = true;
    }
    public boolean hasMusic(){
        return isPlaying;
    }

}
