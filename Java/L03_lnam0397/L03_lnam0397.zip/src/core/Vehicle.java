package core;

public interface Vehicle {
    String toString();

    void numberOfWheels();
}

