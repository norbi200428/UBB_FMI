public class helloNev {
    public static void main(String[] args) {
        System.out.println("Hello Norbi!");
    }
}