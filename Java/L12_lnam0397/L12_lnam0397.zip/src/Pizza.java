import java.awt.*;

public interface Pizza {
    void bake(Graphics g);
    int getPrice();
    String getIngredients();
}
