package lab8;

public interface Plant {
    double getOxigenAmountPerYear();
    int getLifeTime();
    String getRepresentation();
}
